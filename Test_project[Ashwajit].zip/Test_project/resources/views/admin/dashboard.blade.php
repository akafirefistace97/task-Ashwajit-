@extends('admin/layout')

@section('container')

<div class="row">
    <h1>Dashboard</h1>
</div>
@endsection