<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\File;
use WisdomDiala\Countrypkg\Models\Country;
use WisdomDiala\Countrypkg\Models\State;
use App\Models\Files;

class AdminController extends Controller
{   
    public function register_index(){

        
    }

    public function reghister_create(){
        $countries =country::all();
        $states = State::all();
        return view('admin.register' , compact('countries','states'));

    }

    public function register_store(){
        $admin = new Admin();
        $admin->first_name = request('first_name');
        $admin->last_name = request('last_name');
        $admin->email= request('email');
        $admin->mobile= request('mobile');
        $admin->country= request('country');
        $admin->state= request('state');
        $admin->city= request('city');
        $admin->password =Hash::make(request('password'));
        $admin->save();
        return redirect('admin');

    }

    
    public function index(Request $request)
    {
        if($request->session()->has('ADMIN_LOGIN')){
            return redirect('admin/dashboard');
        }else{
            return view('admin.login');
        }
        return view('admin.login');
    }

    public function auth(Request $request)
    {
        $email=$request->post('email');
        $password=$request->post('password');
        // $result=Admin::where(['email'=>$email,'password'=>$password])->get();
        $result=Admin::where(['email'=>$email])->first();

        $folder=$result['first_name'];
        if($result){
            if(Hash::check($request->post('password'),$result->password)){
                $request->session()->put('ADMIN_LOGIN',true);
                $request->session()->put('ADMIN_ID',$result->id);
                $path = public_path('upload/'.$folder);
                if(!File::isDirectory($path)){
                    File::makeDirectory($path, 0777, true, true);
                }

                return redirect('admin/dashboard');
            }else{
                $request->session()->flash('error','Please enter correct password');
                return redirect('admin');
            }
        }else{
            $request->session()->flash('error','Please enter valid login details');
            return redirect('admin');
        }
    }

    public function dashboard()
    {
        $admin = admin::all();
        return view('admin.dashboard',compact('admin'));
    }
    // public function fileUpload(Request $request){
    //     $request->validate([
    //         'file' => 'required|mimes:csv,txt,xlx,xls,pdf,jpg,jpeg,png|max:2048',
    //         'file_name'=>'required',   
    //     ]);

    //     $fileModel = new File;
    //     if($request->file()) {
    //         $fileName = time().'_'.$request->file->getClientOriginalName();
    //         $filePath = $request->file('file')->storeAs('uploads/', $fileName, 'public');
    //         $fileModel->name = time().'_'.$request->file->getClientOriginalName();
    //         $fileModel->file_path = '/storage/' . $filePath;
    //         $fileModel->save();
    //         return back()
    //         ->with('success','File has been uploaded.')
    //         ->with('file', $fileName);
    //     }

    // }

}
