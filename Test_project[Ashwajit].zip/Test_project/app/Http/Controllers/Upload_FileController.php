<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\upload_File;
class Upload_FileController extends Controller
{
    public function index(){
        return view('fileUpload');
    }

    public function store(Request $request){
        $request->validate([
            'file' => 'required|mimes:png,jpg,jpeg,doc,docx,pdf,txt|max:2048'
        ]);

        try{
            $name = now()->timestamp.".{$request->file->getClientOriginalName()}";
            $path = $req->file('file')->storeAs('files', $name, 'public');

            File::create([
                'file'=> "public/upload/{$path}"
            ]);

            return redirect()->back()->with('success','File Upload Successfully!!');
        }catch(\Exception $e){
            return redirect()->back()->with('error','Something goes wrong while uploading file!');
        }
    }
}
